module.exports = {
  apiKey: '',
  discordToken: '',
  clans: [
    {
      tag: '',
      channelID: '',
      color: 3447003
    }
  ],
  timeDelay: 90,
  showLeague: false,
  useRichEmbed: true
}
